# Spring Boot Web Application
##Part 4
This repository has the project files for a tutorial series on Spring Boot available from by website at [Spring Framework Guru](https://springframework.guru/spring-boot-web-application-part-4-spring-mvc/)

In this part of the tutorial series, I show how to setup a Spring MVC controller to suport CRUD operations, a Spring service facad over a Spring Data JPA repository, and Thymeleaf templates for the web application.
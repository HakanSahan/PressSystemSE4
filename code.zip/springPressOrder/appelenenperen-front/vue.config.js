0// vue.config.js
module.exports = {
    devServer:{
        port : 8888
    }
}
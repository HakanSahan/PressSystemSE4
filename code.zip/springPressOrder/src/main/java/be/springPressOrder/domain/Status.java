package be.springPressOrder.domain;

public enum Status {

    NOT_PLANNED,
    PLANNED,
    EXECUTING,
    READY,
    CANCLED;

    
}

package be.springPressOrder.dao;

import be.springPressOrder.domain.Juice;
import org.springframework.data.repository.CrudRepository;

public interface JuiceRepository extends CrudRepository<Juice,Integer> {

}
